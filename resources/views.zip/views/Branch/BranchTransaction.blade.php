 @extends('Admin.layouts.app')
 @section('content')
 <style>
    .opening{
        margin-left:70%;font-weight:bold
    }
    @media only screen and (max-width: 600px) {
    .row1 {
        width:33%;
    }
    .balance{
        font-size:18px;
        
    }
    .balance-row{
        width:40%;
    }
    .opening{
        margin-left:45%;font-weight:bold
    }
}
 </style>
    <div class="pcoded-content">
                        <!-- Page-header start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <div class="page-header-title">
                                           <h5 class="m-b-10">Branch Transaction</h5>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- Page-header end -->
                           <div class="pcoded-inner-content">
                            <!-- Main-body start -->
                            <div class="page-wrapper">
                                <!-- Page-body start -->
                                <div class="page-body">
                                    <div class="card">
                                        <div class="card-block">
                                            <div class="form">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-lg-6 balance-row">
                                                            <div class="col-lg-6">
                                                                <h6>Available</h6>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <h1 class="balance">Balance</h1>
                                                            </div>
                                                         </div>
                                                         <?php
                                                            
                                                            $total_balace =0;
                                                            foreach($paymentss as $payment){
                                                            if($payment->user_id==$user_id && $payment->type == 'Expense'){
                                                                $total_balace = $total_balace - $payment->amount;
                                                            }
                                                            elseif($payment->user_id==$user_id && $payment->type == 'Income'){
                                                                $total_balace = $total_balace + $payment->amount;
                                                            }
                                                            elseif($payment->user_id==$user_id && $payment->type == 'Payout'){
                                                                $total_balace = $total_balace - $payment->amount;
                                                            }
                                                            elseif($payment->user_id==$user_id && $payment->type == 'Payin'){
                                                                $total_balace= $total_balace + $payment->amount;
                                                            }
                                                            
                                                                   
                                                        }
                                                        
                                                     
                                                            ?>
                                                        <div class="col-lg-6 balance-row">
                                                        @if($currency == 1)
                                                             <h1 class="balance">{{number_format($total_balace)}} XAF</h1>
                                                        @else
                                                        <h1 class="balance">{{number_format($total_balace)}} USD</h1>

                                                        @endif
                                                        </div>
                                                    </div>
                                                    <?php 
                                                    $total_balace =0;
                                                    ?>
                                                    @foreach($payments as $payment)
                                                   
                                                     @if($payment->user_id==$user_id && $payment->type == 'Expense')
                                                     <?php
                                                     $remaining_balance = $total_balace - $payment->amount;
                                                     ?>
                                                     <div class="row h-6 border border-secondary m-l-5"></div>
                                                    <br/>
                                                     <div class="row">
                                                        <div class="col-lg-4 row1">
                                                            <button style="font-weight:bold;color:white;background-color:red;border:1px solid red;padding:6px;;margin-bottom:5px">{{$payment->type}}</button>
                                                        </div>
                                                        <div class="col-lg-4 row1">
                                                            <h6>{{$payment->comment}}</h6>
                                                        </div>
                                                        <div class="col-lg-4 row1">
                                                            <div class="col-lg-4">
                                                                <p>-{{number_format($payment->amount)}}</p>
                                                            </div>
                                                            <div class="col-lg-4">
                                                                <p>Bal: {{number_format($remaining_balance)}}</p>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    @elseif($payment->user_id==$user_id && $payment->type == 'Income')
                                                    
                                                     <?php
                                                     $remaining_balance = $total_balace + $payment->amount;
                                                     ?>
                                                    <div class="row h-6 border border-secondary m-l-5"></div>
                                                    <br/>
                                                     <div class="row">
                                                        <div class="col-lg-4 row1">
                                                            <button style="font-weight:bold;color:white;background-color:green;border:1px solid green;padding:6px;margin-bottom:5px">{{$payment->type}}</button>
                                                        </div>
                                                        <div class="col-lg-4 row1">
                                                            <h6>{{$payment->comment}}</h6>
                                                        </div>
                                                        <div class="col-lg-4 row1">
                                                            <div class="col-lg-4">
                                                                <p>+{{number_format($payment->amount)}}</p>
                                                            </div>
                                                            <div class="col-lg-4">
                                                                <p>Bal: {{number_format($remaining_balance)}}</p>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    @elseif($payment->user_id==$user_id && $payment->type == 'Payout')
                                                    <?php
                                                     $remaining_balance = $total_balace - $payment->amount;
                                                     ?>
                                                    <div class="row h-6 border border-secondary m-l-5"></div>
                                                    <br/>
                                                    <a href="{{"transfer_details/".$payment['transfer_id'] }}"> 
                                                    <div class="row">
                                                        <div class="col-lg-4 row1">
                                                            <button style="font-weight:bold;color:white;background-color:red;border:1px solid red;padding:6px;;margin-bottom:5px">{{$payment->type}}</button>
                                                        </div>
                                                        <div class="col-lg-4 row1">
                                                        <h6>{{$payment->sender_name}} for {{$payment->receiver_name}}</h6>
                                                        </div>
                                                        <div class="col-lg-4 row1">
                                                            <div class="col-lg-4">
                                                                <p>-{{number_format($payment->amount)}}</p>
                                                            </div>
                                                            <div class="col-lg-4">
                                                                <p>Bal: {{number_format($remaining_balance)}}</p>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    </a>
                                                    @elseif($payment->user_id==$user_id && $payment->type == 'Payin')
                                                    <?php
                                                     $remaining_balance = $total_balace + $payment->amount;
                                                     ?>
                                                    <div class="row h-6 border border-secondary m-l-5"></div>
                                                    <br/>
                                                    <a href="{{"transfer_details/".$payment['transfer_id'] }}">
                                                     <div class="row">
                                                     <div class="col-lg-4 row1">
                                                            <button style="font-weight:bold;color:white;background-color:green;border:1px solid green;padding:6px;;margin-bottom:5px">Payin</button>
                                                        </div>
                                                        <div class="col-lg-4 row1">
                                                        <h6>{{$payment->sender_name}} for {{$payment->receiver_name}}</h6>
                                                        </div>
                                                        <div class="col-lg-4 row1">
                                                            <div class="col-lg-4">
                                                                <p>+{{number_format($payment->amount)}}</p>
                                                            </div>
                                                            <div class="col-lg-4">
                                                                <p>Bal: {{number_format($remaining_balance)}}</p>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    </a>
                                                    @endif
                                                    <?php
                                                    $total_balace = $remaining_balance;
                                                    ?>
                                                    @endforeach
                                                    
                                                        <!-- Line -->
                                                   
                                                    <div class="row h-6 border border-secondary m-l-5"></div>
                                                    
                                               <br>
                                               
                                                </div>
                                                {!! $payments->render() !!}

                                            </div>
                                        </div>
                                    </div>



                                    <!-- Project statustic end -->
                                </div>
                            </div>
                        </div>
                    </div>
@endsection
