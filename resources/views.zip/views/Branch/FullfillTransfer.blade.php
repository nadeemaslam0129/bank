
 @extends('Admin.layouts.app')
 @section('content')
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <style>
    @media only screen and (max-width: 600px) {
    .row1 {
        background-color:red;
        width:200px;
        }
}
  .active {
    background-color: #3db4fc24;
  }

  .down_icon {
    -webkit-transform: rotate(-90deg);
    transform: rotate(-90deg)
  }
</style>
  <div class="pcoded-content">
                        <!-- Page-header start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <div class="page-header-title">
                                          <h5 class="m-b-10">Branch Transaction</h5>
                                            <ul class="breadcrumb float-left">
                                                <li>
                                                    <a href="#"> <i class="fa fa-home"></i></a>
                                                </li>
                                                <li> /<a href="#"> Fullfill Transfer</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- Page-header end -->
                        <div class="pcoded-inner-content">
                            <!-- Main-body start -->
                            

                            <div class="main-body">
                                <div class="page-wrapper">
                                    <!-- Page-body start -->
                                    <div class="page-body">
                                    @if (session('alert'))
                                                    <div class="alert alert-success">
                                                        {{ session('alert') }}
                                                    </div>
                                    @endif
                                        <div class="card">
                                            <div class="card-block">
                                                <div class="row justify-content-center">
                                                            <div class="col-1">
                                                                <img class="img-70 img-radius" src="https://static.vecteezy.com/system/resources/previews/000/574/512/original/vector-sign-of-user-icon.jpg" alt="This is image">

                                                            </div>
                                                            <div class="col-10 mx-0 ml-3">
                                                                <div class="col-8 mx-0">
                                                                    <h2>{{$transfer->sending_amount}} {{$transfer->sender_currency}} </h2>
                                                                </div>
                                                                <div class="col-12 mx-0">
                                                                    <h6>{{$transfer->sender_name}} for {{$transfer->receiver_name}}</h6>
                                                                </div>
                                                            </div>
                                                </div>
                                                 <div class="row justify-content-center">
                                                    <div class="col-10 mt-2">
                                                        <h6>Created by {{$user_name}} by {{$transfer->created_at->diffForHumans()}}</h6>
                                                    </div>

                                                </div>
                                                <h3>Sender Details</h3>
                                                <hr>
                                                <div class="row">
                                                         <div class="col-4">
                                                            <h6>Name :</h6>
                                                         </div>
                                                         <div class="col-8">
                                                            <h6> {{$transfer->sender_name}}</h6>
                                                         </div>
                                                </div>
                                                 <div class="row">
                                                         <div class="col-4">
                                                            <h6>Address :</h6>
                                                         </div>
                                                         <div class="col-8">
                                                            <h6> {{$transfer->sender_address}}</h6>
                                                         </div>
                                                </div>
                                                <div class="row">
                                                         <div class="col-4">
                                                            <h6>Phone :</h6>
                                                         </div>
                                                         <div class="col-8">
                                                            <h6> {{$transfer->sender_phone}}</h6>
                                                         </div>
                                                </div>
                                                 <div class="row">
                                                         <div class="col-4">
                                                            <h6>Amount :</h6>
                                                         </div>
                                                         <div class="col-8">
                                                            <h6> {{number_format($transfer->sending_amount)}} {{$transfer->sender_currency}}</h6>
                                                         </div>
                                                </div>
                                                 <h3>Receiver Details</h3>
                                                <hr>
                                               <div class="row">
                                                         <div class="col-4">
                                                            <h6>Name :</h6>
                                                         </div>
                                                         <div class="col-8">
                                                            <h6> {{$transfer->receiver_name}}</h6>
                                                         </div>
                                                </div>
                                                 <div class="row">
                                                         <div class="col-4">
                                                            <h6>Address :</h6>
                                                         </div>
                                                         <div class="col-8">
                                                            <h6>{{$transfer->receiver_address}}</h6>
                                                         </div>
                                                </div>
                                                <div class="row">
                                                         <div class="col-4">
                                                            <h6>Phone :</h6>
                                                         </div>
                                                         <div class="col-8">
                                                            <h6>{{$transfer->receiver_phone}}</h6>
                                                         </div>
                                                </div>
                                                @if($transfer->status == 'closed')
                                                <div class="row">
                                                         <div class="col-4">
                                                            <h6>Amount Paid :</h6>
                                                         </div>
                                                         <div class="col-4">
                                                         <h6>{{$transfer->receiving_amount}} {{$transfer->receiver_currency}}</h6>
                                                         </div>
                                                          
                                                </div>
                                                <br>
                                                <div class="row">
                                                         <div class="col-4">
                                                            <h6>Payment Receipt 1:</h6>
                                                         </div>
                                                         <div class="col-8">
                                                            <img src="{{URL::asset($transfer->receipt_image) }}"" style="height:100px;width:100px">
                                                         </div>
                                                         <div class="w3-container">
                                                            <button onclick="document.getElementById('id03').style.display='block'" class="w3-button w3-black">Zoom Image</button>

                                                            <div id="id03" class="w3-modal" style="margin-left:20%;height:80%;width:50%;background-color:white">
                                                               <div class="w3-modal-content">
                                                                  <div class="w3-container">
                                                                  <span onclick="document.getElementById('id03').style.display='none'" class="w3-button w3-display-topright">&times;</span>
                                                                  <img src="{{URL::asset($transfer->receipt_image) }}"" style="height:100%;width:100%">
                                                                  </div>
                                                               </div>
                                                            </div>
                                                         </div>
                                                </div>
                                                <br>
                                                <div class="row">

                                                  <div class="col-4">
                                                            <h6>Comment 1:</h6>
                                                 </div>
                                                   <div class="col-8">
                                                   <h6>{{$transfer->comment}}</h6>
                                                    </div>
                                                </div>
                                                <hr>
                                                 <div class="row">
                                                         <div class="col-4">
                                                            <h6>Payment Receipt 2:</h6>
                                                         </div>
                                                         <div class="col-8">
                                                            <img src="{{URL::asset($transfer->receipt_image2) }}"" style="height:100px;width:100px">
                                                         </div>
                                                         <div class="w3-container">
                                                            <button onclick="document.getElementById('id02').style.display='block'" class="w3-button w3-black">Zoom Image</button>

                                                            <div id="id02" class="w3-modal" style="margin-left:20%;height:80%;width:50%;background-color:white">
                                                               <div class="w3-modal-content">
                                                                  <div class="w3-container">
                                                                  <span onclick="document.getElementById('id02').style.display='none'" class="w3-button w3-display-topright">&times;</span>
                                                                  <img src="{{URL::asset($transfer->receipt_image2) }}"" style="height:100%;width:100%">
                                                                  </div>
                                                               </div>
                                                            </div>
                                                         </div>
                                                </div>
                                                <br>
                                                <div class="row">

                                                  <div class="col-4">
                                                            <h6>Comment 2:</h6>
                                                 </div>
                                                   <div class="col-8">
                                                   <h6>{{$transfer->comment2}}</h6>
                                                    </div>
                                                </div>
                                                @elseif($transfer->status == 'open' && $user_id != $transfer->user_id)
                                                <form method="post" action="{{route('update_transfer')}}" enctype="multipart/form-data">
                                                    <input type="hidden" name="id" value="{{$transfer->id}}">
                                                 <div class="row">
                                                         <div class="col-4">
                                                            <h6>Amount Paid :</h6>
                                                         </div>
                                                         <div class="col-4">
                                                         <input name="receiving_amount" value="{{$transfer->receiving_amount}}">{{$transfer->receiver_currency}}
                                                         </div>
                                                          
                                                </div>
                                                <br>
                                                 <div class="row">
                                                         <div class="col-4">
                                                            <h6>Payment Receipt :</h6>
                                                         </div>
                                                         <div class="col-8">
                                                            <input type="file" name="file" id="">
                                                         </div>
                                                </div>
                                                <br>
                                                <div class="row">

                                                  <div class="col-4">
                                                            <h6>Comment:</h6>
                                                 </div>
                                                   <div class="col-8">
                                                   <textarea type="text" class="form-control input-lg" name="comment" id="">{{$transfer->comment}}</textarea>                                                    </div>
                                                </div>
                                                <br>
                                                <button type="submit" class="btn btn-success">Confirm</button>
                                                @csrf
                                                </form>

                                                @else
                                                <div class="row">
                                                         <div class="col-4">
                                                            <h6>Amount Paid :</h6>
                                                         </div>
                                                         <div class="col-4">
                                                         <h6>{{$transfer->receiving_amount}} {{$transfer->receiver_currency}}</h6>
                                                         </div>
                                                          
                                                </div>
                                                <br>
                                                 <div class="row">
                                                         <div class="col-4">
                                                            <h6>Payment Receipt :</h6>
                                                         </div>
                                                         <div class="col-8">
                                                            <img src="{{URL::asset($transfer->receipt_image) }}"" style="height:100px;width:100px">
                                                         </div>
                                                         <div class="w3-container">
                                                            <button onclick="document.getElementById('id01').style.display='block'" class="w3-button w3-black">Zoom Image</button>

                                                            <div id="id01" class="w3-modal" style="margin-left:20%;height:80%;width:50%;background-color:white">
                                                               <div class="w3-modal-content">
                                                                  <div class="w3-container">
                                                                  <span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
                                                                  <img src="{{URL::asset($transfer->receipt_image) }}"" style="height:100%;width:100%">
                                                                  </div>
                                                               </div>
                                                            </div>
                                                         </div>
                                                </div>
                                                <br>
                                                <div class="row">

                                                  <div class="col-4">
                                                            <h6>Comment:</h6>
                                                 </div>
                                                   <div class="col-8">
                                                   <h6>{{$transfer->comment}}</h6>
                                                    </div>
                                                </div>
                                                @endif
                                            </div>


                                    </div>
                                </div>


                                <!-- Page-body end -->
                            </div>
                            <div id="styleSelector"> </div>
                        </div>
                    </div>
                </div>
@endsection
